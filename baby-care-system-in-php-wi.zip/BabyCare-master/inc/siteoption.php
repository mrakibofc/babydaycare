<!--content section for admin-->


	<div class="row">
		<div class="col-lg-2 adminleftmenu">
		    <!-- Static navbar -->
		    <div class="navbar navbar-inverse navbar-static-top" >
		        <div class="navbar-collapse collapse" style="min-height:480px;">
		          <ul class="nav navbar-nav navbar-left">
		              <li><a href="#">Dashboard</a></li><br/>
		              <li><a href="#">Profile</a></li><br/>    
		              <li><a href="#">Theme</a></li><br/>
		              <li><a href="#">User Role</a></li><br/>
		              <li><a href="#">Inbox(10)</a></li><br/>
		              <li><a href="#">Site Options</a></li><br/>              
		              <li><a href="#">Menus</a></li><br/>              
		              <li><a href="#">Posts</a></li><br/>              
		                        
		          </ul>
		        </div><!--/.nav-collapse -->
		    </div>
		</div>

		<!-- body section for admin index -->
		<div class="col-lg-10 adminrightsection">
			<div class="col-lg-5 adminrightsection-box">
				<h4>Total Users</h4><hr/>
				<p id="shiva"><span class="count">1254</span></p>
			</div>
			<div class="col-lg-5 adminrightsection-box">
				<h4>Stistics</h4><hr/>
				<p>1254</p>
			</div>
		</div>

		<div class="col-lg-10 adminrightsection">
			<div class="col-lg-5 adminrightsection-box">
				<h4>Total Posts</h4><hr/>
				<p>1254</p>
			</div>
			<div class="col-lg-5 adminrightsection-box">
				<h4>Showing Posts</h4><hr/>
				<p>1254</p>
			</div>
		</div>
	</div><!-- /row -->

