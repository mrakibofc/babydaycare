	
	<!-- Footer Section -->
	
	<div id="footer">
		<div class="container">
				<center>
					Copyright@2017 <br/>
					Authorized# <a href="http://www.mykodng.com/itech/">iTech SolutionBD</a>
				</center>
		</div>
	</div>
	

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/app.js"></script> 
  </body>
</html>
